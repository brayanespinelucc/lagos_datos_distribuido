# Manual de recuperación

## Alcance de la recuperación

El primer dato que necesita el responsable de la guardia es el dominio afectado. Un proceso caído, un disco perdido y un fallo del host Proxmox tienen procedimientos y alcances distintos. Registre quién abrió el incidente, hora UTC, versión, error exacto, último resultado íntegro y ubicación privada del respaldo correspondiente.


## Intervención y verificación

| Incidente | Diagnóstico y primera acción | Cómo aceptar la recuperación |
|---|---|---|
| Nodo MinIO detenido | Desde el administrador, capture `mc admin info ALIAS`. Confirme si los otros cuatro discos forman el conjunto ensayado EC:2. Conserve la identidad de los seis volúmenes y los nombres de objetos testigo. Arranque el mismo servidor con sus dos volúmenes originales. | Los seis discos retornan, las operaciones a través de HAProxy funcionan y los objetos escritos antes y durante la caída conservan su SHA-256 al leerse desde los nodos. [Procedimiento y acta P3/P4](../moment-01/minio.md) |
| Worker de Kubernetes detenido | Capture condiciones Ready, pods, UID, nodos, EndpointSlices y peticiones al Service. Compruebe la salud del control plane. Inicie el mismo worker y observe los cambios sin forzar una redistribución para la toma de evidencia. | Verifique el mismo UID del nodo, la salud del kubelet, tres nodos Ready y peticiones válidas. Compare UID de las réplicas antes, durante y después. Una réplica con volumen local puede quedar pendiente mientras su nodo no está disponible. [Ensayo P5](../moment-01/rke2.md) |
| Control plane o host único fuera de servicio | Consulte el hipervisor desde el canal administrativo y localice la última copia externa del estado de etcd y de los datos. En el inventario hay un solo servidor RKE2. Documente el alcance de la indisponibilidad. | Una restauración de etcd requiere el snapshot y el token de servidor asociado. En un entorno de ensayo separado verifique recursos, certificados, identidad de volúmenes y operaciones reales antes de promover la recuperación. [Respaldo y restauración RKE2](https://docs.rke2.io/datastore/backup_restore) |
| DAG con error | Lea la primera tarea fallida y su log. Valide hash, permisos y conectividad del endpoint con la identidad de esa etapa. Preserve el manifiesto y los rechazos antes de reproducir. | El mismo lote esperado produce las cinco tareas satisfactorias y concilia sus filas e importes. Si cambia el origen, identifique la corrida como lote nuevo. [Manual y documentación del DAG](../moment-02/manual.md) |
| Trino pierde el catálogo | Conserve el despliegue del coordinador y el respaldo del volumen del metastore. Compruebe tablas, rutas externas y acceso S3. Restaure la definición registrada o el metastore de la versión correspondiente. | La misma sentencia concluye y sus totales coinciden con el lote y la capa Gold. [Catálogo de Trino](../../services/trino/catalog/lago.properties) |
| Grafana presenta una ventana vacía | Compruebe rango, zona horaria, datasource y objetivos en Prometheus. Revise `up` por job antes de interpretar el panel. Conserve la muestra que provocó la alerta. | Un scrape reciente y la consulta PromQL del panel devuelven la serie con sus etiquetas. Verifique por separado los objetivos que siguen sin muestras. [Manual de operación](../moment-03/operacion.md) |

Para una restauración desde copias, ensaye primero en recursos independientes y conserve el original. Informe como duración observada la diferencia entre la acción y la primera validación posterior. Un RPO requiere la marca temporal del último dato recuperable. Los tiempos obtenidos en un único ensayo no establecen un acuerdo de nivel de servicio.
